package com.example.preferencesapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

public class MainActivity extends AppCompatActivity {
    private TextView preferencesTextView;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        preferencesTextView = findViewById(R.id.preferencesTextView);
        Button settingsButton = findViewById(R.id.settingsButton);

        // Initialize SharedPreferences
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        // Set click listener for settings button
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        // Initial load of preferences
        loadPreferences();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload preferences when returning to the activity
        loadPreferences();
    }

    private void loadPreferences() {
        // Get values from SharedPreferences
        String username = sharedPreferences.getString("username", "Not set");
        boolean notifications = sharedPreferences.getBoolean("notifications", false);
        String syncFrequency = sharedPreferences.getString("sync_frequency", "Never");

        // Display current preferences
        String preferencesText = String.format(
                "Current Settings:\n\n" +
                        "Username: %s\n" +
                        "Notifications: %s\n" +
                        "Sync Frequency: %s",
                username,
                notifications ? "Enabled" : "Disabled",
                syncFrequency
        );

        preferencesTextView.setText(preferencesText);
    }
}