package com.example.statusbarapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity {

    private Button btnChangeColor;
    private Button btnToggleVisibility;
    private Button btnLightMode;
    private Button btnDarkMode;
    private boolean isStatusBarVisible = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons
        btnChangeColor = findViewById(R.id.btnChangeColor);
        btnToggleVisibility = findViewById(R.id.btnToggleVisibility);
        btnLightMode = findViewById(R.id.btnLightMode);
        btnDarkMode = findViewById(R.id.btnDarkMode);

        // Change Status Bar Color
        btnChangeColor.setOnClickListener(v -> {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimary));
        });

        // Toggle Status Bar Visibility
        btnToggleVisibility.setOnClickListener(v -> {
            if (isStatusBarVisible) {
                hideStatusBar();
            } else {
                showStatusBar();
            }
            isStatusBarVisible = !isStatusBarVisible;
        });

        // Light Mode (Dark Icons)
        btnLightMode.setOnClickListener(v -> {
            Window window = getWindow();
            window.setStatusBarColor(Color.WHITE);
            // Make status bar icons dark
            View decor = window.getDecorView();
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        });

        // Dark Mode (Light Icons)
        btnDarkMode.setOnClickListener(v -> {
            Window window = getWindow();
            window.setStatusBarColor(Color.BLACK);
            // Make status bar icons light
            View decor = window.getDecorView();
            decor.setSystemUiVisibility(0);
        });
    }

    private void hideStatusBar() {
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
    }

    private void showStatusBar() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // Optional: Override onWindowFocusChanged to maintain fullscreen mode
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && !isStatusBarVisible) {
            hideStatusBar();
        }
    }
}