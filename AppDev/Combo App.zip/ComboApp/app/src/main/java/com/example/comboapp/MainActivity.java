package com.example.comboapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private static final String WEBSITE_URL = "https://tanmay-one.vercel.app/";
    private static final String PHONE_NUMBER = "9254265472";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize WebView
        webView = findViewById(R.id.webView);
        webView.setVisibility(View.GONE);  // Initially hidden

        // Configure WebView
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webView.setWebViewClient(new WebViewClient());

        // Set up button click listeners
        Button websiteButton = findViewById(R.id.websiteButton);
        Button callButton = findViewById(R.id.callButton);

        websiteButton.setOnClickListener(v -> {
            webView.setVisibility(View.VISIBLE);
            webView.loadUrl(WEBSITE_URL);
        });

        callButton.setOnClickListener(v -> {
            Intent dialIntent = new Intent(Intent.ACTION_DIAL);
            dialIntent.setData(Uri.parse("tel:" + PHONE_NUMBER));
            startActivity(dialIntent);
        });
    }

    @Override
    public void onBackPressed() {
        if (webView.getVisibility() == View.VISIBLE) {
            if (webView.canGoBack()) {
                webView.goBack();
            } else {
                webView.setVisibility(View.GONE);
            }
        } else {
            super.onBackPressed();
        }
    }
}