// MainActivity.java
package com.example.animationapp;

import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private CustomDrawingView customDrawingView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        customDrawingView = findViewById(R.id.customDrawingView);

        // Setup animation buttons
        Button rotateButton = findViewById(R.id.rotateButton);
        Button scaleButton = findViewById(R.id.scaleButton);
        Button translateButton = findViewById(R.id.translateButton);
        Button drawButton = findViewById(R.id.drawButton);
        Button propertyAnimButton = findViewById(R.id.propertyAnimButton);

        // Rotate Animation
        rotateButton.setOnClickListener(v -> {
            Animation rotateAnim = AnimationUtils.loadAnimation(this, R.anim.rotate);
            imageView.startAnimation(rotateAnim);
        });

        // Scale Animation
        scaleButton.setOnClickListener(v -> {
            Animation scaleAnim = AnimationUtils.loadAnimation(this, R.anim.scale);
            imageView.startAnimation(scaleAnim);
        });

        // Translate Animation
        translateButton.setOnClickListener(v -> {
            Animation translateAnim = AnimationUtils.loadAnimation(this, R.anim.translate);
            imageView.startAnimation(translateAnim);
        });

        // Custom Drawing Animation
        drawButton.setOnClickListener(v -> {
            customDrawingView.startAnimation();
        });

        // Property Animation
        propertyAnimButton.setOnClickListener(v -> performPropertyAnimation());
    }

    private void performPropertyAnimation() {
        // Create multiple animations
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(imageView, View.SCALE_X, 1.0f, 1.5f, 1.0f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(imageView, View.SCALE_Y, 1.0f, 1.5f, 1.0f);
        ObjectAnimator rotation = ObjectAnimator.ofFloat(imageView, View.ROTATION, 0f, 360f);

        // Combine animations
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(scaleX, scaleY, rotation);
        animatorSet.setDuration(1500);
        animatorSet.start();
    }
}