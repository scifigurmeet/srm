// CustomDrawingView.java
package com.example.animationapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.animation.ValueAnimator;

public class CustomDrawingView extends View {
    private Paint paint;
    private float circleRadius = 50f;
    private float centerX, centerY;
    private ValueAnimator animator;

    public CustomDrawingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);

        // Initialize the animator
        animator = ValueAnimator.ofFloat(50f, 150f);
        animator.setDuration(1000);
        animator.setRepeatCount(1);
        animator.setRepeatMode(ValueAnimator.REVERSE);

        animator.addUpdateListener(animation -> {
            circleRadius = (float) animation.getAnimatedValue();
            invalidate(); // Redraw the view
        });
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        centerX = w / 2f;
        centerY = h / 2f;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Draw a circle that will be animated
        canvas.drawCircle(centerX, centerY, circleRadius, paint);
    }

    public void startAnimation() {
        animator.start();
    }
}