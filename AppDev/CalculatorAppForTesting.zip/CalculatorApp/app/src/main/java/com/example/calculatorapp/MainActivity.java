package com.example.calculatorapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText num1Input, num2Input;
    private TextView resultText;
    private Calculator calculator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calculator = new Calculator();
        num1Input = findViewById(R.id.num1_input);
        num2Input = findViewById(R.id.num2_input);
        resultText = findViewById(R.id.result_text);

        Button addButton = findViewById(R.id.add_button);
        addButton.setOnClickListener(v -> performCalculation('+'));
    }

    private void performCalculation(char operation) {
        try {
            int num1 = Integer.parseInt(num1Input.getText().toString());
            int num2 = Integer.parseInt(num2Input.getText().toString());
            int result = 0;

            switch (operation) {
                case '+':
                    result = calculator.add(num1, num2);
                    break;
            }

            resultText.setText(String.valueOf(result));
        } catch (NumberFormatException e) {
            resultText.setText("Invalid input");
        }
    }
}