package com.example.calculatorapp;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.espresso.IdlingRegistry;
import androidx.test.espresso.IdlingResource;
import android.view.View;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

@RunWith(AndroidJUnit4.class)
public class MainActivityTest {

    @Rule
    public ActivityScenarioRule<MainActivity> activityRule =
            new ActivityScenarioRule<>(MainActivity.class);

    @Test
    public void testAddOperation() {
        // Input test numbers and close keyboard
        onView(withId(R.id.num1_input))
                .perform(typeText("5"), closeSoftKeyboard());
        onView(withId(R.id.num2_input))
                .perform(typeText("3"), closeSoftKeyboard());

        // Wait a bit to ensure input is processed
        try {
            Thread.sleep(250);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Click add button
        onView(withId(R.id.add_button))
                .perform(click());

        // Wait a bit for calculation
        try {
            Thread.sleep(250);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Check result
        onView(withId(R.id.result_text))
                .check(matches(withText("8")));
    }

    @Test
    public void testInvalidInput() {
        // Leave inputs empty and click
        onView(withId(R.id.add_button))
                .perform(click());

        // Wait a bit for UI update
        try {
            Thread.sleep(250);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Check error message
        onView(withId(R.id.result_text))
                .check(matches(withText("Invalid input")));
    }
}