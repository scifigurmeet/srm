package com.example.taskapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class TaskDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "TaskDB";
    private static final int DATABASE_VERSION = 2;

    // Tables
    private static final String TABLE_CATEGORIES = "categories";
    private static final String TABLE_TASKS = "tasks";

    // Common column
    private static final String COLUMN_ID = "id";

    // Categories table columns
    private static final String COLUMN_CATEGORY_NAME = "category_name";

    // Tasks table columns
    private static final String COLUMN_TASK_TITLE = "title";
    private static final String COLUMN_TASK_DESCRIPTION = "description";
    private static final String COLUMN_CATEGORY_ID = "category_id";
    private static final String COLUMN_COMPLETED = "completed";

    public TaskDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create categories table
        String createCategoriesTable = "CREATE TABLE " + TABLE_CATEGORIES + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_CATEGORY_NAME + " TEXT NOT NULL UNIQUE)";

        // Create tasks table with foreign key
        String createTasksTable = "CREATE TABLE " + TABLE_TASKS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TASK_TITLE + " TEXT NOT NULL, " +
                COLUMN_TASK_DESCRIPTION + " TEXT, " +
                COLUMN_CATEGORY_ID + " INTEGER, " +
                COLUMN_COMPLETED + " INTEGER DEFAULT 0, " +
                "FOREIGN KEY(" + COLUMN_CATEGORY_ID + ") REFERENCES " +
                TABLE_CATEGORIES + "(" + COLUMN_ID + "))";

        db.execSQL(createCategoriesTable);
        db.execSQL(createTasksTable);

        // Insert default category
        ContentValues defaultCategory = new ContentValues();
        defaultCategory.put(COLUMN_CATEGORY_NAME, "General");
        db.insert(TABLE_CATEGORIES, null, defaultCategory);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORIES);
        onCreate(db);
    }

    // Category operations
    public long addCategory(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CATEGORY_NAME, name);
        long id = db.insert(TABLE_CATEGORIES, null, values);
        db.close();
        return id;
    }

    public Cursor getAllCategories() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_CATEGORIES, null, null, null, null, null,
                COLUMN_CATEGORY_NAME + " ASC");
    }

    // Task operations
    public long addTask(String title, String description, long categoryId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TASK_TITLE, title);
        values.put(COLUMN_TASK_DESCRIPTION, description);
        values.put(COLUMN_CATEGORY_ID, categoryId);
        long id = db.insert(TABLE_TASKS, null, values);
        db.close();
        return id;
    }

    public Cursor getTasksWithCategories() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT t.*, c." + COLUMN_CATEGORY_NAME +
                " FROM " + TABLE_TASKS + " t " +
                "LEFT JOIN " + TABLE_CATEGORIES + " c " +
                "ON t." + COLUMN_CATEGORY_ID + " = c." + COLUMN_ID +
                " ORDER BY t." + COLUMN_COMPLETED + ", t." + COLUMN_ID + " DESC";
        return db.rawQuery(query, null);
    }

    public int toggleTaskComplete(long taskId) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "UPDATE " + TABLE_TASKS +
                " SET " + COLUMN_COMPLETED + " = CASE WHEN " +
                COLUMN_COMPLETED + " = 0 THEN 1 ELSE 0 END " +
                "WHERE " + COLUMN_ID + " = ?";
        db.execSQL(query, new String[]{String.valueOf(taskId)});
        return 1;
    }

    public int deleteTask(long taskId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_TASKS, COLUMN_ID + "=?",
                new String[]{String.valueOf(taskId)});
        db.close();
        return result;
    }
}