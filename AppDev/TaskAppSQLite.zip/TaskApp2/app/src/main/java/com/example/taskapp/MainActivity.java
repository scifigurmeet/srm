package com.example.taskapp;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private TaskDbHelper dbHelper;
    private EditText taskTitleInput, taskDescInput, categoryInput;
    private Spinner categorySpinner;
    private ListView taskListView;
    private HashMap<Integer, Long> categoryIdMap;
    private ArrayAdapter<String> tasksAdapter;
    private ArrayList<String> tasksList;
    private ArrayList<Long> taskIds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new TaskDbHelper(this);
        categoryIdMap = new HashMap<>();
        tasksList = new ArrayList<>();
        taskIds = new ArrayList<>();

        initializeViews();
        loadCategories();
        loadTasks();
        setupListeners();
    }

    private void initializeViews() {
        taskTitleInput = findViewById(R.id.taskTitleInput);
        taskDescInput = findViewById(R.id.taskDescInput);
        categoryInput = findViewById(R.id.categoryInput);
        categorySpinner = findViewById(R.id.categorySpinner);
        taskListView = findViewById(R.id.taskListView);

        tasksAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, tasksList);
        taskListView.setAdapter(tasksAdapter);
    }

    private void loadCategories() {
        ArrayList<String> categories = new ArrayList<>();
        Cursor cursor = dbHelper.getAllCategories();
        int index = 0;

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                categories.add(name);
                categoryIdMap.put(index++, id);
            } while (cursor.moveToNext());
        }
        cursor.close();

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, categories);
        categoryAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);
    }

    private void loadTasks() {
        tasksList.clear();
        taskIds.clear();
        Cursor cursor = dbHelper.getTasksWithCategories();

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String title = cursor.getString(1);
                String desc = cursor.getString(2);
                String category = cursor.getString(5);
                boolean completed = cursor.getInt(4) == 1;

                String status = completed ? "[✓] " : "[ ] ";
                tasksList.add(status + title + "\n" + desc + "\nCategory: " + category);
                taskIds.add(id);
            } while (cursor.moveToNext());
        }
        cursor.close();
        tasksAdapter.notifyDataSetChanged();
    }

    private void setupListeners() {
        findViewById(R.id.addTaskButton).setOnClickListener(v -> addTask());
        findViewById(R.id.addCategoryButton).setOnClickListener(v -> addCategory());

        taskListView.setOnItemClickListener((parent, view, position, id) ->
                toggleTaskComplete(position));

        taskListView.setOnItemLongClickListener((parent, view, position, id) -> {
            deleteTask(position);
            return true;
        });
    }

    private void addTask() {
        String title = taskTitleInput.getText().toString();
        String description = taskDescInput.getText().toString();
        int categoryPosition = categorySpinner.getSelectedItemPosition();
        long categoryId = categoryIdMap.get(categoryPosition);

        if (!title.isEmpty()) {
            dbHelper.addTask(title, description, categoryId);
            taskTitleInput.setText("");
            taskDescInput.setText("");
            loadTasks();
            Toast.makeText(this, "Task added", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please enter a title",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void addCategory() {
        String category = categoryInput.getText().toString();
        if (!category.isEmpty()) {
            dbHelper.addCategory(category);
            categoryInput.setText("");
            loadCategories();
            Toast.makeText(this, "Category added", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please enter a category name",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleTaskComplete(int position) {
        long taskId = taskIds.get(position);
        dbHelper.toggleTaskComplete(taskId);
        loadTasks();
    }

    private void deleteTask(int position) {
        long taskId = taskIds.get(position);
        dbHelper.deleteTask(taskId);
        loadTasks();
        Toast.makeText(this, "Task deleted", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}