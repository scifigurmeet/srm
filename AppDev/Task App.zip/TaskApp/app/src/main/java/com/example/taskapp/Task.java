package com.example.taskapp;

import java.io.Serializable;

public class Task implements Serializable {
    private String title;
    private String description;
    private String priority;
    private String dateCreated;

    public Task(String title, String description, String priority, String dateCreated) {
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.dateCreated = dateCreated;
    }

    // Getters and Setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    public String getDateCreated() { return dateCreated; }
    public void setDateCreated(String dateCreated) { this.dateCreated = dateCreated; }

    @Override
    public String toString() {
        return title;
    }
}