package com.example.taskapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;

public class TaskDetailActivity extends AppCompatActivity {
    private EditText taskTitleEdit;
    private EditText taskDescriptionEdit;
    private Spinner prioritySpinner;
    private TextView dateCreatedText;
    private Button saveButton;
    private Task currentTask;
    private int position = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_detail);

        // Initialize views
        taskTitleEdit = findViewById(R.id.taskTitleEdit);
        taskDescriptionEdit = findViewById(R.id.taskDescriptionEdit);
        prioritySpinner = findViewById(R.id.prioritySpinner);
        dateCreatedText = findViewById(R.id.dateCreatedText);
        saveButton = findViewById(R.id.saveButton);

        // Setup priority spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.priority_levels, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        prioritySpinner.setAdapter(adapter);

        // Get task details from intent
        Intent intent = getIntent();
        if (intent != null) {
            currentTask = (Task) intent.getSerializableExtra("task");
            position = intent.getIntExtra("position", -1);

            if (currentTask != null) {
                // Fill in the task details
                taskTitleEdit.setText(currentTask.getTitle());
                taskDescriptionEdit.setText(currentTask.getDescription());
                dateCreatedText.setText(getString(R.string.date_created,
                        currentTask.getDateCreated()));

                // Set spinner selection
                String priority = currentTask.getPriority();
                for (int i = 0; i < prioritySpinner.getAdapter().getCount(); i++) {
                    if (prioritySpinner.getAdapter().getItem(i).toString()
                            .equalsIgnoreCase(priority)) {
                        prioritySpinner.setSelection(i);
                        break;
                    }
                }
            }
        }

        // Setup save button
        saveButton.setOnClickListener(v -> saveTask());
    }

    private void saveTask() {
        if (currentTask != null) {
            // Update task with new values
            currentTask.setTitle(taskTitleEdit.getText().toString());
            currentTask.setDescription(taskDescriptionEdit.getText().toString());
            currentTask.setPriority(prioritySpinner.getSelectedItem().toString());

            // Create result intent
            Intent resultIntent = new Intent();
            resultIntent.putExtra("task", currentTask);
            resultIntent.putExtra("position", position);
            setResult(RESULT_OK, resultIntent);
        }
        finish();
    }

    @Override
    public void onBackPressed() {
        // Save changes when back button is pressed
        saveTask();
        super.onBackPressed();
    }
}