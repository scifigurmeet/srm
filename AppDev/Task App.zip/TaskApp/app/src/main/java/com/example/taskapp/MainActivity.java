package com.example.taskapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private ListView taskListView;
    private ArrayList<Task> taskList;
    private ArrayAdapter<Task> taskAdapter;
    private FloatingActionButton addTaskButton;
    private static final int TASK_DETAIL_REQUEST_CODE = 1;
    private static ArrayList<Task> savedTaskList = new ArrayList<>();  // Static list to maintain state

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        taskListView = findViewById(R.id.taskListView);
        addTaskButton = findViewById(R.id.addTaskButton);

        // Initialize task list and adapter
        taskList = new ArrayList<>();

        // If we have saved tasks, use them, otherwise create sample tasks
        if (savedTaskList.isEmpty()) {
            // Add sample tasks with current date
            String currentDate = new SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
                    .format(new Date());
            savedTaskList.add(new Task("Complete Android Assignment",
                    "Finish the task app implementation", "High", currentDate));
            savedTaskList.add(new Task("Study for exam",
                    "Review Android fundamentals", "Medium", currentDate));
        }

        // Add all saved tasks to current list
        taskList.addAll(savedTaskList);

        taskAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                taskList);

        // Set adapter to ListView
        taskListView.setAdapter(taskAdapter);

        // Set click listener for list items
        taskListView.setOnItemClickListener((parent, view, position, id) -> {
            Task selectedTask = taskList.get(position);
            openTaskDetail(selectedTask, position);
        });

        // Set click listener for FAB
        addTaskButton.setOnClickListener(view -> {
            showAddTaskDialog();
        });
    }

    private void openTaskDetail(Task task, int position) {
        Intent intent = new Intent(this, TaskDetailActivity.class);
        intent.putExtra("task", task);
        intent.putExtra("position", position);
        startActivityForResult(intent, TASK_DETAIL_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == TASK_DETAIL_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Task editedTask = (Task) data.getSerializableExtra("task");
            int position = data.getIntExtra("position", -1);
            if (position != -1 && editedTask != null) {
                taskList.set(position, editedTask);
                savedTaskList.set(position, editedTask);  // Update saved list
                taskAdapter.notifyDataSetChanged();
            }
        }
    }

    private void showAddTaskDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.add_new_task);

        // Set up the input
        final EditText input = new EditText(this);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton(R.string.add, (dialog, which) -> {
            String taskTitle = input.getText().toString();
            if (!taskTitle.isEmpty()) {
                String currentDate = new SimpleDateFormat("MMM dd, yyyy HH:mm",
                        Locale.getDefault()).format(new Date());
                Task newTask = new Task(taskTitle, "", "Low", currentDate);
                taskList.add(newTask);
                savedTaskList.add(newTask);  // Add to saved list
                taskAdapter.notifyDataSetChanged();
            }
        });
        builder.setNegativeButton(R.string.cancel, (dialog, which) -> dialog.cancel());

        builder.show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Make sure saved list is up to date
        savedTaskList.clear();
        savedTaskList.addAll(taskList);
    }
}