package com.example.counterapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnOpenSecond = findViewById(R.id.btnOpenSecond);
        Button btnOpenWebsite = findViewById(R.id.btnOpenWebsite);
        Button btnShare = findViewById(R.id.btnShare);
        EditText editTextToShare = findViewById(R.id.editTextToShare);

        // 1. Explicit Intent - Opens SecondActivity
        btnOpenSecond.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            startActivity(intent);
        });

        // 2. Implicit Intent - Opens Website
        btnOpenWebsite.setOnClickListener(view -> {
            Uri webpage = Uri.parse("https://www.codelucky.com");
            Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
            startActivity(intent);
        });

        // 3. Share Intent
        btnShare.setOnClickListener(view -> {
            String textToShare = editTextToShare.getText().toString();
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, textToShare);
            startActivity(Intent.createChooser(intent, "Share via"));
        });
    }
}