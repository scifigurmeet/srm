package com.example.tabletapp;

import android.os.Bundle;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

public class MainActivity extends AppCompatActivity implements ListFragmentX.OnItemSelectedListener {
    private boolean isTwoPane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check if we're in two-pane mode (tablet) by checking if detail container exists
        FrameLayout detailContainer = findViewById(R.id.detail_container);
        isTwoPane = detailContainer != null;

        // Always add the list fragment
        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.list_container, new ListFragmentX())
                    .commit();
        }
    }

    @Override
    public void onItemSelected(int position) {
        Bundle args = new Bundle();
        args.putInt("position", position);
        DetailFragment detailFragment = new DetailFragment();
        detailFragment.setArguments(args);

        if (isTwoPane) {
            // Tablet: Show detail fragment in detail_container
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.detail_container, detailFragment)
                    .commit();
        } else {
            // Phone: Replace list with detail fragment, add to back stack
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.list_container, detailFragment)
                    .addToBackStack(null)
                    .commit();
        }
    }
}