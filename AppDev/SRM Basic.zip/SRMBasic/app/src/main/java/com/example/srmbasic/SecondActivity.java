package com.example.srmbasic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class SecondActivity extends AppCompatActivity {
    private CardView secondCard;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // Initialize views
        secondCard = findViewById(R.id.secondCard);
        backButton = findViewById(R.id.backButton);

        // Load and start fade-in animation
        Animation fadeIn = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
        fadeIn.setDuration(1000);
        secondCard.startAnimation(fadeIn);

        // Set up button click listener
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create and start animation for button press
                Animation scaleAnimation = AnimationUtils.loadAnimation(SecondActivity.this, R.anim.button_scale);
                backButton.startAnimation(scaleAnimation);

                // Navigate back with a delay to show animation
                backButton.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                        // Add slide transition
                        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                    }
                }, 200);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}