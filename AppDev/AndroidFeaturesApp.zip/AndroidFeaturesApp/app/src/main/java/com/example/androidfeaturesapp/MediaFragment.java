package com.example.androidfeaturesapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.VideoView;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import java.io.File;
import java.io.IOException;

public class MediaFragment extends Fragment {
    private Button recordButton;
    private Button playButton;
    private Button cameraButton;
    private VideoView videoView;
    private MediaRecorder mediaRecorder;
    private MediaPlayer mediaPlayer;
    private String audioFilePath;
    private boolean isRecording = false;
    private Uri videoUri;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 2;
    private static final int VIDEO_CAPTURE_REQUEST_CODE = 3;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_media, container, false);

        recordButton = view.findViewById(R.id.recordButton);
        playButton = view.findViewById(R.id.playButton);
        cameraButton = view.findViewById(R.id.cameraButton);
        videoView = view.findViewById(R.id.videoView);

        // Set up audio file path
        audioFilePath = new File(requireContext().getExternalFilesDir(null),
                "audio_record.mp3").getAbsolutePath();

        // Audio Recording
        recordButton.setOnClickListener(v -> {
            if (checkPermissions()) {
                if (!isRecording) {
                    startRecording();
                    recordButton.setText("Stop Recording");
                } else {
                    stopRecording();
                    recordButton.setText("Start Recording");
                }
                isRecording = !isRecording;
            }
        });

        // Audio Playback
        playButton.setOnClickListener(v -> {
            if (mediaPlayer == null) {
                startPlaying();
            } else {
                stopPlaying();
            }
        });

        // Video Recording
        cameraButton.setOnClickListener(v -> {
            if (checkPermissions()) {
                startVideoRecording();
            }
        });

        return view;
    }

    private boolean checkPermissions() {
        if (ActivityCompat.checkSelfPermission(requireContext(),
                Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(requireContext(),
                        Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(new String[]{
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA
            }, CAMERA_PERMISSION_REQUEST_CODE);
            return false;
        }
        return true;
    }

    private void startRecording() {
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mediaRecorder.setOutputFile(audioFilePath);

        try {
            mediaRecorder.prepare();
            mediaRecorder.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void stopRecording() {
        if (mediaRecorder != null) {
            mediaRecorder.stop();
            mediaRecorder.release();
            mediaRecorder = null;
        }
    }

    private void startPlaying() {
        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(audioFilePath);
            mediaPlayer.prepare();
            mediaPlayer.start();
            playButton.setText("Stop Playing");

            mediaPlayer.setOnCompletionListener(mp -> {
                stopPlaying();
                playButton.setText("Play Recording");
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void stopPlaying() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
            playButton.setText("Play Recording");
        }
    }

    private void startVideoRecording() {
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        File videoFile = new File(requireContext().getExternalFilesDir(null),
                "video_record.mp4");
        videoUri = FileProvider.getUriForFile(requireContext(),
                "com.example.androidfeaturesapp.fileprovider", videoFile);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, videoUri);
        startActivityForResult(intent, VIDEO_CAPTURE_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == VIDEO_CAPTURE_REQUEST_CODE && resultCode == requireActivity().RESULT_OK) {
            videoView.setVideoURI(videoUri);
            videoView.start();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                    grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                // Permissions granted
            }
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mediaRecorder != null) {
            mediaRecorder.release();
            mediaRecorder = null;
        }
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}