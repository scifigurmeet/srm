package com.example.androidfeaturesapp;

import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import androidx.fragment.app.Fragment;

public class AnimationFragment extends Fragment {
    private ImageView animatedImage;
    private Button rotateButton;
    private Button scaleButton;
    private Button translateButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_animation, container, false);

        animatedImage = view.findViewById(R.id.animatedImage);
        rotateButton = view.findViewById(R.id.rotateButton);
        scaleButton = view.findViewById(R.id.scaleButton);
        translateButton = view.findViewById(R.id.translateButton);

        rotateButton.setOnClickListener(v -> startRotationAnimation());
        scaleButton.setOnClickListener(v -> startScaleAnimation());
        translateButton.setOnClickListener(v -> startTranslateAnimation());

        return view;
    }

    private void startRotationAnimation() {
        ObjectAnimator rotation = ObjectAnimator.ofFloat(animatedImage, "rotation", 0f, 360f);
        rotation.setDuration(1000);
        rotation.start();
    }

    private void startScaleAnimation() {
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(animatedImage, "scaleX", 1f, 1.5f, 1f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(animatedImage, "scaleY", 1f, 1.5f, 1f);

        AnimatorSet scaleSet = new AnimatorSet();
        scaleSet.playTogether(scaleX, scaleY);
        scaleSet.setDuration(1000);
        scaleSet.start();
    }

    private void startTranslateAnimation() {
        ObjectAnimator translateX = ObjectAnimator.ofFloat(animatedImage, "translationX", 0f, 200f, 0f);
        translateX.setDuration(1000);
        translateX.start();
    }
}